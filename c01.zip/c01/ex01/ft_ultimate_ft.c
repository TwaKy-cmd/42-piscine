/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: khebert <khebert@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 09:26:53 by khebert           #+#    #+#             */
/*   Updated: 2025/09/18 12:44:00 by khebert          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

// int	main(void)
// {
// 	int	depart;
// 	depart = '0';
// 	int	*ptr1 = &depart;
// 	int	**ptr2 = &ptr1;
// 	int	***ptr3 = &ptr2;
// 	int	****ptr4 = &ptr3;
// 	int	*****ptr5 = &ptr4;
// 	int	******ptr6 = &ptr5;
// 	int	*******ptr7 = &ptr6;
// 	int	********ptr8 = &ptr7;
// 	int	*********ptr9 = &ptr8;
// 	ft_ultimate_ft(ptr9);
// 	printf("%d", depart);
// 	return (0);
// }
